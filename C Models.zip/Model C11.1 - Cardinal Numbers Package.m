(* ::Package:: *)

(* ::Title:: *)
(*Model C11.1: Cardinal Numbers Package*)


(* ::Text:: *)
(*This package contains a Cardinality function that can handle infinite sets, as well as some variables that represent those cardinal numbers. This allows the user to wield notions of countability algebraically.*)
(*(Note that the format of this package file is my preference, you can arrange things however you wish)*)


(* ::Item:: *)
(*Cardinal Numbers*)


(* ::Text::Initialization:: *)
(*(*This is just a note about what symbols this Package uses - there are no definitions of these, this is just a list of symbols that the functions below will recognize in a special way.*)*)
(*(*Infinite sets: \[DoubleStruckCapitalN], \[DoubleStruckCapitalZ], \[DoubleStruckCapitalQ], \[DoubleStruckCapitalR], \[DoubleStruckCapitalC]*)*)
(*(*Cardinals: Subscript[\[Aleph], 0], Subscript[\[Aleph], 1], Subscript[\[Aleph], 2]*)*)


(* ::Item:: *)
(*Functions*)


(* ::Input::Initialization:: *)
Cardinality::usage="Takes in a set or domain and returns a number if the set is finite, or a cardinal number if the set is infinite (and of a recognizeable form).";

Cardinality[list_]:=Switch[ToString[list],"\[DoubleStruckCapitalN]","\!\(\*SubscriptBox[\(\[Aleph]\), \(0\)]\)","\[DoubleStruckCapitalZ]","\!\(\*SubscriptBox[\(\[Aleph]\), \(0\)]\)","\[DoubleStruckCapitalQ]","\!\(\*SubscriptBox[\(\[Aleph]\), \(0\)]\)","\[DoubleStruckCapitalR]","\!\(\*SubscriptBox[\(\[Aleph]\), \(1\)]\)","\[DoubleStruckCapitalC]","\!\(\*SubscriptBox[\(\[Aleph]\), \(1\)]\)",_,Length[list]];


(* ::Item:: *)
(*Operators*)


(* ::Input::Initialization:: *)
TildeTilde::usage="Checks that two sets have the same cardinality.";

TildeTilde[x_,y_]:=Cardinality[x]==Cardinality[y];
